/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.icmc.vicg.gl.model.jwavefront;

/**
 *
 * @author PC
 */
public class Normal {
    
    public Normal(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public float x;
    public float y;
    public float z;
}
